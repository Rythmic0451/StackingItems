// Autores:
public class Lid {
    private static final int STANDARD_HEIGHT = 1;
    private Rectangle shape;
    private int size;
    private int color;
    private int xPosition;
    private int yPosition;
    private boolean isVisible;
    private Cup cup;
    private int cupNumber;

    public Lid(int cupNumber, int size, int color) {
        this.cupNumber = cupNumber;
        this.size = size;
        this.color = color;
        this.xPosition = 70;
        this.yPosition = 15;
        this.isVisible = false;
        this.cup = null;
        this.shape = new Rectangle();
        shape.changeSize(STANDARD_HEIGHT, size);
        shape.changeColor(getColorString(color));
    }

    public int getHeight() {
        return STANDARD_HEIGHT;
    }

    public Cup getCup() {
        return cup;
    }

    public int getSize() {
        return size;
    }

    public int getColor() {
        return color;
    }

    public void givePosition(int x, int y) {
        int deltaX = x - this.xPosition;
        int deltaY = y - this.yPosition;

        this.xPosition = x;
        this.yPosition = y;

        if (isVisible) {
            shape.moveHorizontal(deltaX);
            shape.moveVertical(deltaY);
        }
    }

    public void makeVisible() {
        if (!isVisible) {
            isVisible = true;
            shape.makeVisible();
        }
    }

    public void makeInvisible() {
        if (isVisible) {
            shape.makeInvisible();
            isVisible = false;
        }
    }

    public int getCupNumber() {
        return cupNumber;
    }

    public void setCup(Cup cup) {
        this.cup = cup;
    }

    private String getColorString(int colorCode) {
        String[] colors = {"red", "blue", "green", "yellow", "magenta"};
        if (colorCode >= 0 && colorCode < colors.length) {
            return colors[colorCode];
        }
        return "black";
    }
}
