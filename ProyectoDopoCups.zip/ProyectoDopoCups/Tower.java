// Autores: Largo-Sarmiento
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Tower {
    private int width;
    private int maxHeight;
    private boolean isVisible;
    private int currentHeight;
    private ArrayList<Cup> cups;
    private ArrayList<Lid> lids;
    private ArrayList<Object> stackedItems;
    private Rectangle towerBase;
    private ArrayList<Rectangle> heightMarkers;

    private static final int BASE_X = 100;
    private static final int BASE_Y = 400;
    private static final int CM_TO_PIXELS = 10;

    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        this.isVisible = false;
        this.currentHeight = 0;
        this.cups = new ArrayList<Cup>();
        this.lids = new ArrayList<Lid>();
        this.stackedItems = new ArrayList<Object>();
        this.heightMarkers = new ArrayList<Rectangle>();

        towerBase = new Rectangle();
        towerBase.changeSize(5, width * CM_TO_PIXELS);
        towerBase.changeColor("black");

        createHeightMarkers();
    }

    private void createHeightMarkers() {
        for (int i = 0; i <= maxHeight; i++) {
            Rectangle marker = new Rectangle();
            marker.changeSize(1, 5);
            marker.changeColor("gray");
            heightMarkers.add(marker);
        }
    }

    public void pushCup(int numberCups) {
        Cup existingCup = findCupByNumber(numberCups);

        if (existingCup != null) {
            if (isVisible) {
                JOptionPane.showMessageDialog(null, 
                    "Ya existe una taza con el número " + numberCups);
            }
            return;
        }

        int cupHeight = numberCups;

        if (currentHeight + cupHeight > maxHeight) {
            if (isVisible) {
                JOptionPane.showMessageDialog(null, 
                    "La taza no cabe en la torre. Altura actual: " + currentHeight + 
                    ", espacio disponible: " + (maxHeight - currentHeight));
            }
            return;
        }

        String[] colors = {"red", "blue", "green", "yellow", "magenta"};
        String color = colors[(int)(Math.random() * colors.length)];

        Cup newCup = new Cup(numberCups);
        newCup.setSize(width * CM_TO_PIXELS);
        newCup.setColor(color);

        int yPos = BASE_Y - (currentHeight * CM_TO_PIXELS);
        newCup.givePosition(BASE_X, yPos);

        cups.add(newCup);
        stackedItems.add(newCup);
        currentHeight += cupHeight;

        if (isVisible) {
            newCup.makeVisible();
        }
    }

    public void popCup() {
        if (cups.isEmpty()) {
            if (isVisible) {
                JOptionPane.showMessageDialog(null, "No hay tazas en la torre");
            }
            return;
        }

        Cup lastCup = null;
        for (int i = stackedItems.size() - 1; i >= 0; i--) {
            if (stackedItems.get(i) instanceof Cup) {
                lastCup = (Cup) stackedItems.get(i);
                stackedItems.remove(i);
                break;
            }
        }

        if (lastCup != null) {
            if (lastCup.isCover() && lastCup.getLid() != null) {
                Lid lid = lastCup.getLid();
                lids.remove(lid);
                lid.makeInvisible();
                currentHeight -= lid.getHeight();
                stackedItems.remove(lid);
            }

            lastCup.makeInvisible();
            cups.remove(lastCup);
            currentHeight -= lastCup.getHeight();

            repositionAllItems();
        }
    }

    public void removeCup(int numberCups) {
        Cup cupToRemove = findCupByNumber(numberCups);

        if (cupToRemove == null) {
            if (isVisible) {
                JOptionPane.showMessageDialog(null, 
                    "No existe una taza con el número " + numberCups);
            }
            return;
        }

        if (cupToRemove.isCover() && cupToRemove.getLid() != null) {
            Lid lid = cupToRemove.getLid();
            lids.remove(lid);
            lid.makeInvisible();
            currentHeight -= lid.getHeight();
            stackedItems.remove(lid);
        }

        cupToRemove.makeInvisible();
        cups.remove(cupToRemove);
        stackedItems.remove(cupToRemove);
        currentHeight -= cupToRemove.getHeight();

        repositionAllItems();
    }

    public void pushLid(int cupNumber) {
        Lid existingLid = findLidByNumber(cupNumber);

        if (existingLid != null) {
            if (isVisible) {
                JOptionPane.showMessageDialog(null, 
                    "Ya existe una tapa con el número " + cupNumber);
            }
            return;
        }

        if (currentHeight + 1 > maxHeight) {
            if (isVisible) {
                JOptionPane.showMessageDialog(null, 
                    "La tapa no cabe en la torre");
            }
            return;
        }

        Cup associatedCup = findCupByNumber(cupNumber);
        int colorCode = 0;

        if (associatedCup != null) {
            String cupColor = associatedCup.getColor();
            colorCode = getColorCode(cupColor);

            if (associatedCup.isCover()) {
                if (isVisible) {
                    JOptionPane.showMessageDialog(null, 
                        "La taza " + cupNumber + " ya tiene una tapa");
                }
                return;
            }
        }

        Lid newLid = new Lid(cupNumber, width * CM_TO_PIXELS, colorCode);

        int yPos = BASE_Y - (currentHeight * CM_TO_PIXELS);
        newLid.givePosition(BASE_X, yPos);

        lids.add(newLid);
        stackedItems.add(newLid);
        currentHeight += 1;

        if (associatedCup != null) {
            int cupIndex = stackedItems.indexOf(associatedCup);
            int lidIndex = stackedItems.indexOf(newLid);

            if (lidIndex == cupIndex + 1) {
                associatedCup.setLid(newLid);
                newLid.setCup(associatedCup);
            }
        }

        if (isVisible) {
            newLid.makeVisible();
        }
    }

    public void popLid() {
        if (lids.isEmpty()) {
            if (isVisible) {
                JOptionPane.showMessageDialog(null, "No hay tapas en la torre");
            }
            return;
        }

        Lid lastLid = null;
        for (int i = stackedItems.size() - 1; i >= 0; i--) {
            if (stackedItems.get(i) instanceof Lid) {
                lastLid = (Lid) stackedItems.get(i);
                stackedItems.remove(i);
                break;
            }
        }

        if (lastLid != null) {
            if (lastLid.getCup() != null) {
                lastLid.getCup().removeLid();
            }

            lastLid.makeInvisible();
            lids.remove(lastLid);
            currentHeight -= 1;

            repositionAllItems();
        }
    }

    public void removeLid(int cupNumber) {
        Lid lidToRemove = findLidByNumber(cupNumber);

        if (lidToRemove == null) {
            if (isVisible) {
                JOptionPane.showMessageDialog(null, 
                    "No existe una tapa con el número " + cupNumber);
            }
            return;
        }

        if (lidToRemove.getCup() != null) {
            lidToRemove.getCup().removeLid();
        }

        lidToRemove.makeInvisible();
        lids.remove(lidToRemove);
        stackedItems.remove(lidToRemove);
        currentHeight -= 1;

        repositionAllItems();
    }

    public void orderTower() {
        ArrayList<Object> allItems = new ArrayList<Object>();
        allItems.addAll(stackedItems);

        allItems.sort((a, b) -> {
            int heightA = getItemHeight(a);
            int heightB = getItemHeight(b);
            return heightB - heightA;
        });

        stackedItems.clear();
        currentHeight = 0;

        for (Object item : allItems) {
            int itemHeight = getItemHeight(item);
            if (currentHeight + itemHeight <= maxHeight) {
                stackedItems.add(item);
                currentHeight += itemHeight;
            }
        }

        repositionAllItems();
    }

    public void reverseTower() {
        ArrayList<Object> reversedItems = new ArrayList<Object>();
        for (int i = stackedItems.size() - 1; i >= 0; i--) {
            reversedItems.add(stackedItems.get(i));
        }

        stackedItems.clear();
        currentHeight = 0;

        for (Object item : reversedItems) {
            int itemHeight = getItemHeight(item);
            if (currentHeight + itemHeight <= maxHeight) {
                stackedItems.add(item);
                currentHeight += itemHeight;
            }
        }

        repositionAllItems();
    }

    public int height() {
        return currentHeight;
    }

    public int[] lidedCups() {
        ArrayList<Integer> covered = new ArrayList<Integer>();

        for (Cup cup : cups) {
            if (cup.isCover()) {
                covered.add(cup.getNumberCups());
            }
        }

        int[] result = new int[covered.size()];
        for (int i = 0; i < covered.size(); i++) {
            result[i] = covered.get(i);
        }

        return result;
    }

    public String[][] stackingItems() {
        String[][] result = new String[stackedItems.size()][2];

        for (int i = 0; i < stackedItems.size(); i++) {
            Object item = stackedItems.get(i);
            if (item instanceof Cup) {
                Cup cup = (Cup) item;
                result[i][0] = "cup";
                result[i][1] = String.valueOf(cup.getNumberCups());
            } else if (item instanceof Lid) {
                Lid lid = (Lid) item;
                result[i][0] = "lid";
                result[i][1] = String.valueOf(lid.getCupNumber());
            }
        }

        return result;
    }

    public void makeVisible() {
        if (!isVisible) {
            isVisible = true;
            towerBase.makeVisible();

            towerBase.moveHorizontal(BASE_X - 70);
            towerBase.moveVertical(BASE_Y - 15);

            for (int i = 0; i < heightMarkers.size(); i++) {
                Rectangle marker = heightMarkers.get(i);
                marker.makeVisible();
                marker.moveHorizontal(BASE_X - 10 - 70);
                marker.moveVertical(BASE_Y - (i * CM_TO_PIXELS) - 15);
            }

            for (Object item : stackedItems) {
                if (item instanceof Cup) {
                    ((Cup) item).makeVisible();
                } else if (item instanceof Lid) {
                    ((Lid) item).makeVisible();
                }
            }
        }
    }

    public void makeInvisible() {
        if (isVisible) {
            isVisible = false;
            towerBase.makeInvisible();

            for (Rectangle marker : heightMarkers) {
                marker.makeInvisible();
            }

            for (Object item : stackedItems) {
                if (item instanceof Cup) {
                    ((Cup) item).makeInvisible();
                } else if (item instanceof Lid) {
                    ((Lid) item).makeInvisible();
                }
            }
        }
    }

    public void exit() {
        makeInvisible();
        cups.clear();
        lids.clear();
        stackedItems.clear();
    }

    public boolean ok() {
        return isVisible;
    }

    private void repositionAllItems() {
        int accumulatedHeight = 0;

        for (Object item : stackedItems) {
            int yPos = BASE_Y - (accumulatedHeight * CM_TO_PIXELS);

            if (item instanceof Cup) {
                Cup cup = (Cup) item;
                cup.givePosition(BASE_X, yPos);
                accumulatedHeight += cup.getHeight();
            } else if (item instanceof Lid) {
                Lid lid = (Lid) item;
                lid.givePosition(BASE_X, yPos);
                accumulatedHeight += lid.getHeight();
            }
        }
    }

    private Cup findCupByNumber(int numberCups) {
        for (Cup cup : cups) {
            if (cup.getNumberCups() == numberCups) {
                return cup;
            }
        }
        return null;
    }

    private Lid findLidByNumber(int cupNumber) {
        for (Lid lid : lids) {
            if (lid.getCupNumber() == cupNumber) {
                return lid;
            }
        }
        return null;
    }

    private int getItemHeight(Object item) {
        if (item instanceof Cup) {
            return ((Cup) item).getHeight();
        } else if (item instanceof Lid) {
            return ((Lid) item).getHeight();
        }
        return 0;
    }

    private int getColorCode(String color) {
        switch(color) {
            case "red": return 0;
            case "blue": return 1;
            case "green": return 2;
            case "yellow": return 3;
            case "magenta": return 4;
            default: return 0;
        }
    }
}
