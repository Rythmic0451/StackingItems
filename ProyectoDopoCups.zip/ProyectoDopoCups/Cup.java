// Autores: Largo - Sarmiento
public class Cup {
    private int topCup;
    private int cupHeight;
    private Rectangle shape;
    private boolean covered;
    private int numberCups;
    private int size;
    private String color;
    private int xPosition;
    private int yPosition;
    private boolean isVisible;
    private Lid lid;

    public Cup(int numberCups) {
        this.numberCups = numberCups;
        this.cupHeight = numberCups;
        this.size = 0;
        this.color = "";
        this.xPosition = 70;
        this.yPosition = 15;
        this.isVisible = false;
        this.covered = false;
        this.topCup = -1;
        this.lid = null;
        this.shape = new Rectangle();
    }

    public int getHeight() {
        return cupHeight;
    }

    public void setLid(Lid lid) {
        this.lid = lid;
        if (lid != null) {
            this.topCup = lid.getCupNumber();
            this.covered = true;
            lid.setCup(this);
        }
    }

    public void removeLid() {
        this.lid = null;
        this.topCup = -1;
        this.covered = false;
    }

    public void cover() {
        this.covered = true;
    }

    public boolean isCover() {
        return covered;
    }

    public int getSize() {
        return size;
    }

    public String getColor() {
        return color;
    }

    public void givePosition(int x, int y) {
        int deltaX = x - this.xPosition;
        int deltaY = y - this.yPosition;

        this.xPosition = x;
        this.yPosition = y;

        if (isVisible) {
            shape.moveHorizontal(deltaX);
            shape.moveVertical(deltaY);
        }

        if (covered && lid != null) {
            lid.givePosition(x, y - cupHeight);
        }
    }

    public void makeVisible() {
        if (!isVisible) {
            isVisible = true;
            shape.makeVisible();

            if (covered && lid != null) {
                lid.makeVisible();
            }
        }
    }

    public void makeInvisible() {
        if (isVisible) {
            shape.makeInvisible();
            isVisible = false;

            if (covered && lid != null) {
                lid.makeInvisible();
            }
        }
    }

    public int getNumberCups() {
        return numberCups;
    }

    public Lid getLid() {
        return lid;
    }

    public void setSize(int size) {
        this.size = size;
        shape.changeSize(cupHeight, size);
    }

    public void setColor(String color) {
        this.color = color;
        shape.changeColor(color);
    }
}
